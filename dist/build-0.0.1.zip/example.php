<?php
use GedasTheEvil\LaravelTranslationCheck\TranslationCheck;
(new TranslationCheck(__DIR__))->runInConsole();
