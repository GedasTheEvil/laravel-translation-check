<?php

namespace GedasTheEvil\LaravelTranslationCheck\Exceptions;

class Exception extends \Exception
{
}
