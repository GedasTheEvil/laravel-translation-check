<?php

namespace GedasTheEvil\LaravelTranslationCheck\Exceptions;

class TranslationNotFound extends Exception
{

}