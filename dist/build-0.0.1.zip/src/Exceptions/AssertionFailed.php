<?php

namespace GedasTheEvil\LaravelTranslationCheck\Exceptions;

class AssertionFailed extends Exception
{

}